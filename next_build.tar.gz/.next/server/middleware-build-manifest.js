globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/yiItgLXNZT4pHdGfBBIoY/_buildManifest.js",
    "static/yiItgLXNZT4pHdGfBBIoY/_ssgManifest.js",
    "static/yiItgLXNZT4pHdGfBBIoY/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0tkz9du~023q..js",
    "static/chunks/0i8xhtq6~~_ho.js",
    "static/chunks/10zoor32h-nuw.js",
    "static/chunks/0e-wrhqh4h3r5.js",
    "static/chunks/turbopack-0n974ivye1-sv.js"
  ]
};
