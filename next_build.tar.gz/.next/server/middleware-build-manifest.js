globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/9OD3NzHBHrMKDcDbj2seq/_buildManifest.js",
    "static/9OD3NzHBHrMKDcDbj2seq/_ssgManifest.js",
    "static/9OD3NzHBHrMKDcDbj2seq/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yly7xtwdzywq.js",
    "static/chunks/152k2ttyoaood.js",
    "static/chunks/0rawexwt9d8ke.js",
    "static/chunks/0e-wrhqh4h3r5.js",
    "static/chunks/turbopack-0k-fnt96zus5x.js"
  ]
};
