1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0~dwm1~odl3--.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
3:I[37457,["/_next/static/chunks/0~dwm1~odl3--.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"i6y9n2GHK83-7bCrLWXv-"}
