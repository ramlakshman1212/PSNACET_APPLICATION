var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/forms/submit/route.js")
R.c("server/chunks/[root-of-the-server]__0ucpxal._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_forms_submit_route_actions_017i4f-.js")
R.m(86794)
module.exports=R.m(86794).exports
