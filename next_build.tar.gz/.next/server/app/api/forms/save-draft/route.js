var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/forms/save-draft/route.js")
R.c("server/chunks/[root-of-the-server]__0zc4vvb._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/_next-internal_server_app_api_forms_save-draft_route_actions_0qa~w8o.js")
R.m(87807)
module.exports=R.m(87807).exports
