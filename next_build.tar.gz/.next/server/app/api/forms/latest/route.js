var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/forms/latest/route.js")
R.c("server/chunks/[root-of-the-server]__08v38pj._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_forms_latest_route_actions_01rs1a5.js")
R.m(83967)
module.exports=R.m(83967).exports
