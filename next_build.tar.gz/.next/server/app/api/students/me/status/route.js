var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/me/status/route.js")
R.c("server/chunks/[root-of-the-server]__0-8fnlx._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_students_me_status_route_actions_0~ads2s.js")
R.m(8964)
module.exports=R.m(8964).exports
