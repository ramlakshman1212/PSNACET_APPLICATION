var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/me/route.js")
R.c("server/chunks/[root-of-the-server]__11uhhfh._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_students_me_route_actions_09cyx9b.js")
R.m(58296)
module.exports=R.m(58296).exports
