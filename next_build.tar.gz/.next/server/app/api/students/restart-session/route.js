var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/restart-session/route.js")
R.c("server/chunks/[root-of-the-server]__07orwoq._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_students_restart-session_route_actions_062vikm.js")
R.m(32287)
module.exports=R.m(32287).exports
