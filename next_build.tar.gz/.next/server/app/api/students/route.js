var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/students/route.js")
R.c("server/chunks/[root-of-the-server]__0teern3._.js")
R.c("server/chunks/_0_1wiy1._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/_next-internal_server_app_api_students_route_actions_06o718t.js")
R.m(86342)
module.exports=R.m(86342).exports
