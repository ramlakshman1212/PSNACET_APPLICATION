var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/toggle-lock/route.js")
R.c("server/chunks/[root-of-the-server]__12_6zfs._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_students_toggle-lock_route_actions_0qauy_2.js")
R.m(52995)
module.exports=R.m(52995).exports
