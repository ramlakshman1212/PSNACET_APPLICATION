var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/session/me/route.js")
R.c("server/chunks/[root-of-the-server]__10arovm._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_session_me_route_actions_0b-1e_h.js")
R.m(42602)
module.exports=R.m(42602).exports
