var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/documents/route.js")
R.c("server/chunks/[root-of-the-server]__02zj9m6._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_documents_route_actions_07t.5bx.js")
R.m(8564)
module.exports=R.m(8564).exports
