var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/documents/bulk-download/route.js")
R.c("server/chunks/[root-of-the-server]__00uildn._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/0zjb_server_app_api_admin_documents_bulk-download_route_actions_07b~hwk.js")
R.m(57200)
module.exports=R.m(57200).exports
