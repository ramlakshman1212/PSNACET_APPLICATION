var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/documents/upload/route.js")
R.c("server/chunks/[root-of-the-server]__0rbkxhw._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_documents_upload_route_actions_117lze3.js")
R.m(33504)
module.exports=R.m(33504).exports
