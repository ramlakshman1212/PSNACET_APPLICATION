var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/excel-exports/download/route.js")
R.c("server/chunks/[root-of-the-server]__0vbioyd._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__0l6f5er._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_excel-exports_download_route_actions_050gy7c.js")
R.m(85745)
module.exports=R.m(85745).exports
