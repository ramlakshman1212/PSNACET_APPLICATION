var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/route.js")
R.c("server/chunks/[root-of-the-server]__0xox09m._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_settings_route_actions_13ms-ys.js")
R.m(11094)
module.exports=R.m(11094).exports
