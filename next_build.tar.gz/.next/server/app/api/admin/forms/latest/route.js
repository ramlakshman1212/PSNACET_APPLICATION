var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/forms/latest/route.js")
R.c("server/chunks/[root-of-the-server]__04n02zz._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_forms_latest_route_actions_0.ur35f.js")
R.m(23551)
module.exports=R.m(23551).exports
