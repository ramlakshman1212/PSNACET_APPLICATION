var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/forms/draft/route.js")
R.c("server/chunks/[root-of-the-server]__0m8oh~b._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_forms_draft_route_actions_0lvzlqi.js")
R.m(98027)
module.exports=R.m(98027).exports
