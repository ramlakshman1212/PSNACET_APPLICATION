var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/forms/promote/route.js")
R.c("server/chunks/[root-of-the-server]__0ilwrd2._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_forms_promote_route_actions_0xy8f_a.js")
R.m(59331)
module.exports=R.m(59331).exports
