var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/dashboard-metrics/route.js")
R.c("server/chunks/[root-of-the-server]__0zq9iig._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_dashboard-metrics_route_actions_0om_x2p.js")
R.m(10784)
module.exports=R.m(10784).exports
