var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/account/route.js")
R.c("server/chunks/[root-of-the-server]__07rxigg._.js")
R.c("server/chunks/node_modules_bcryptjs_index_0bjz0ul.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_account_route_actions_138~da7.js")
R.m(76903)
module.exports=R.m(76903).exports
