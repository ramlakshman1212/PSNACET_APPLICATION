var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/bulk-upload/route.js")
R.c("server/chunks/[root-of-the-server]__0ybv6ww._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_bulk-upload_route_actions_117-cez.js")
R.m(8460)
module.exports=R.m(8460).exports
