var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/id-cards-export/route.js")
R.c("server/chunks/[root-of-the-server]__0fhongw._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/node_modules_xlsx_xlsx_mjs_0eepc5h._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_id-cards-export_route_actions_0rxunqd.js")
R.m(88818)
module.exports=R.m(88818).exports
