var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/hostel-images/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0.u6oz7._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_hostel-images_[id]_route_actions_0tsl333.js")
R.m(35031)
module.exports=R.m(35031).exports
