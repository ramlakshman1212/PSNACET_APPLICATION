var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/hostel-images/route.js")
R.c("server/chunks/[root-of-the-server]__0l6~bcc._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_hostel-images_route_actions_0wrdnha.js")
R.m(5083)
module.exports=R.m(5083).exports
