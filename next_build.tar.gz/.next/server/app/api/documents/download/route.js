var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/documents/download/route.js")
R.c("server/chunks/[root-of-the-server]__0d-zw9s._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_api_documents_download_route_actions_0dkzwdt.js")
R.m(40369)
module.exports=R.m(40369).exports
