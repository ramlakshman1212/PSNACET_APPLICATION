var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/documents/route.js")
R.c("server/chunks/[root-of-the-server]__0x_9~3b._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_api_documents_route_actions_0ykfuvn.js")
R.m(92792)
module.exports=R.m(92792).exports
