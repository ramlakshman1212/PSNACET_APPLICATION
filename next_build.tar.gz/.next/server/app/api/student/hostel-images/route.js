var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/hostel-images/route.js")
R.c("server/chunks/[root-of-the-server]__0zhdiw7._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_student_hostel-images_route_actions_0px-w6n.js")
R.m(26631)
module.exports=R.m(26631).exports
