var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0d399xc._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_logout_route_actions_09pke_j.js")
R.m(80787)
module.exports=R.m(80787).exports
