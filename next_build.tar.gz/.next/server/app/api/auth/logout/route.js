var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0keb.d5._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_logout_route_actions_0fm~3ij.js")
R.m(83932)
module.exports=R.m(83932).exports
