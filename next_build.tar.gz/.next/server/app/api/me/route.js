var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/me/route.js")
R.c("server/chunks/[root-of-the-server]__0hwtg9l._.js")
R.c("server/chunks/_07qwnow._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_api_me_route_actions_0awbrgh.js")
R.m(23033)
module.exports=R.m(23033).exports
