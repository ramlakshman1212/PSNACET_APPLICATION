module.exports=[57859,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_hostel-images_route_actions_0px-w6n.js.map