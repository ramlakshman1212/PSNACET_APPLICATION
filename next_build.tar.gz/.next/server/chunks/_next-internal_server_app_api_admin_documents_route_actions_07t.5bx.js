module.exports=[4857,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_documents_route_actions_07t.5bx.js.map