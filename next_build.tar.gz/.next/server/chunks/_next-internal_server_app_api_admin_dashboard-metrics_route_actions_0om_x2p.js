module.exports=[97075,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_dashboard-metrics_route_actions_0om_x2p.js.map