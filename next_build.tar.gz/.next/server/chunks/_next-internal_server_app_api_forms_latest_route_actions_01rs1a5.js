module.exports=[51669,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_forms_latest_route_actions_01rs1a5.js.map