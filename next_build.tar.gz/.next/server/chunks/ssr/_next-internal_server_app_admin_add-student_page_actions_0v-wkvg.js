module.exports=[86759,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_add-student_page_actions_0v-wkvg.js.map