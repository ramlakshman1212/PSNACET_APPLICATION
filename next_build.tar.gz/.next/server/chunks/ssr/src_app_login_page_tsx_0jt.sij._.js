module.exports=[93482,a=>{"use strict";var b=a.i(87924);a.s(["default",0,function(){return(0,b.jsx)("main",{className:"w-full min-h-screen bg-white"})}])}];

//# sourceMappingURL=src_app_login_page_tsx_0jt.sij._.js.map