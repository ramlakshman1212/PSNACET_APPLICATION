module.exports=[95447,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_form_page_actions_0kkg2bn.js.map