module.exports=[59539,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_student-forms_page_actions_11.c-s6.js.map