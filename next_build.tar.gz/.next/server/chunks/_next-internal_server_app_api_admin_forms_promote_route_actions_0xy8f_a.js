module.exports=[52693,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_forms_promote_route_actions_0xy8f_a.js.map