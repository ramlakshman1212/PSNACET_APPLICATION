module.exports=[30544,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_hostel-images_route_actions_0wrdnha.js.map