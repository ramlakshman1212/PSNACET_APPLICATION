module.exports=[19942,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_id-cards-export_route_actions_0rxunqd.js.map