module.exports=[78668,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_students_toggle-lock_route_actions_0qauy_2.js.map