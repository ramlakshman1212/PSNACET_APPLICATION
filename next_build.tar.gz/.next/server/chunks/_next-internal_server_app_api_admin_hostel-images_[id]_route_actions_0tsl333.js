module.exports=[55041,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_hostel-images_%5Bid%5D_route_actions_0tsl333.js.map