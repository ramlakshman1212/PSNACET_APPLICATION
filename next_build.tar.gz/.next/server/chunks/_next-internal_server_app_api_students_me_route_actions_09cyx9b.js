module.exports=[83369,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_students_me_route_actions_09cyx9b.js.map