module.exports=[7742,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_forms_latest_route_actions_0.ur35f.js.map